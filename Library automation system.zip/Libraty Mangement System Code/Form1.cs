﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); // Initialize the Form
        }

        // When button1 is clicked, open the UserLogin form
        private void button1_Click(object sender, EventArgs e)
        {
            UserLogin M = new UserLogin();
            M.Show();
            this.Hide(); // Hide the current form
        }

        // When button3 (Exit) is clicked, close the application
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Bid farewell to your application
        }

        // This is where the magic begins (Form1 is loaded)
        private void Form1_Load(object sender, EventArgs e)
        {
            // Welcome to the Library Management System
            // Where books come to life, and readers unite!
        }
    }
}
